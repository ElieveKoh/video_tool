#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import streamlit as st
import streamlit.components.v1 as components
import subprocess
import os
import tempfile
import shutil
import threading
import time
import json
from pathlib import Path
import webbrowser
from threading import Thread
import re
import signal
from datetime import datetime

class VideoConverterCore:
    """비디오 변환 핵심 기능 클래스"""
    
    # 코덱별 설정 상수
    CODEC_CONFIG = {
        "h264": {
            "encoder": "libx264",
            "hw_encoder": "h264_videotoolbox",  # macOS 하드웨어 가속
            "param_name": "preset",
            "bitrates": {"4k": 20, "hd": 12, "sd": 5},
            "bitrate_bonus": {"4k": 5, "hd": 3, "sd": 2}
        },
        "h265": {
            "encoder": "libx265",
            "hw_encoder": "hevc_videotoolbox",  # macOS 하드웨어 가속
            "param_name": "preset",
            "bitrates": {"4k": 15, "hd": 8, "sd": 3},
            "bitrate_bonus": {"4k": 3, "hd": 2, "sd": 1}
        },
        "vp9": {
            "encoder": "libvpx-vp9",
            "hw_encoder": None,  # VP9는 하드웨어 가속 미지원
            "param_name": "speed",
            "bitrates": {"4k": 16, "hd": 8, "sd": 4},
            "bitrate_bonus": {"4k": 4, "hd": 2, "sd": 1}
        },
        "av1": {
            "encoder": "libaom-av1",
            "hw_encoder": None,  # AV1은 하드웨어 가속 미지원
            "param_name": "cpu-used",
            "bitrates": {"4k": 12, "hd": 6, "sd": 3},
            "bitrate_bonus": {"4k": 3, "hd": 2, "sd": 1}
        }
    }
    
    # 해상도별 설정
    RESOLUTION_CONFIG = {
        "4k": {"width": 3840, "height": 2160},
        "1440p": {"width": 2560, "height": 1440},
        "1080p": {"width": 1920, "height": 1080},
        "720p": {"width": 1280, "height": 720},
        "480p": {"width": 854, "height": 480}
    }
    
    # 품질 프리셋 매핑
    QUALITY_PRESETS = {
        "fast": {"h264": "fast", "h265": "fast", "vp9": 4, "av1": 8},
        "balanced": {"h264": "medium", "h265": "medium", "vp9": 2, "av1": 6},
        "high": {"h264": "slow", "h265": "slow", "vp9": 1, "av1": 4}
    }
    
    def __init__(self):
        self.current_process = None
        self.conversion_stopped = False
        self.base_dir = os.path.dirname(os.path.abspath(__file__))
        self.hw_accel_available = self._check_hw_accel()

    def _check_hw_accel(self):
        """하드웨어 가속 사용 가능 여부 확인 (macOS VideoToolbox)"""
        import sys
        if sys.platform != 'darwin':
            return False

        try:
            ffmpeg_path = self._get_ffmpeg_path()
            result = subprocess.run(
                [ffmpeg_path, '-hide_banner', '-encoders'],
                capture_output=True, text=True, timeout=5
            )
            # VideoToolbox 인코더가 있는지 확인
            return 'h264_videotoolbox' in result.stdout
        except:
            return False
    
    def _get_ffmpeg_path(self):
        """FFmpeg 경로 찾기 (로컬 bin 우선)"""
        local_ffmpeg = os.path.join(self.base_dir, 'bin', 'ffmpeg')
        if os.path.exists(local_ffmpeg):
            return local_ffmpeg
        return 'ffmpeg'  # 시스템 PATH에서 찾기
    
    def _get_ffprobe_path(self):
        """FFprobe 경로 찾기 (로컬 bin 우선)"""
        local_ffprobe = os.path.join(self.base_dir, 'bin', 'ffprobe')
        if os.path.exists(local_ffprobe):
            return local_ffprobe
        return 'ffprobe'  # 시스템 PATH에서 찾기
        
    def get_video_info(self, file_path):
        """FFprobe를 사용해서 비디오 정보 추출"""
        try:
            # 로컬 바이너리 우선 사용
            ffprobe_path = self._get_ffprobe_path()
            
            cmd = [
                ffprobe_path, '-v', 'error', '-select_streams', 'v:0',
                '-show_entries', 'stream=width,height,codec_name,bit_rate',
                '-show_entries', 'format=duration,bit_rate',
                '-of', 'json', file_path
            ]
            
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
            if result.returncode == 0:
                data = json.loads(result.stdout)
                
                video_stream = data.get('streams', [{}])[0]
                format_info = data.get('format', {})
                
                return {
                    'width': int(video_stream.get('width', 0)),
                    'height': int(video_stream.get('height', 0)),
                    'codec': video_stream.get('codec_name', 'unknown'),
                    'duration': float(format_info.get('duration', 0)),
                    'bitrate': int(format_info.get('bit_rate', 0))
                }
        except Exception as e:
            print(f"비디오 정보 추출 오류: {e}")
            return None
    
    def get_codec_options(self, file_path, target_codec, target_resolution, quality_preset, target_fps="original", scan_type="progressive", custom_video_bitrate=None, custom_audio_bitrate=None):
        """코덱별 변환 옵션 생성 (프레임레이트 및 스캔 타입 지원, 커스텀 비트레이트 옵션)"""
        # 비디오 정보 가져오기
        video_info = self.get_video_info(file_path)
        if not video_info:
            print(f"❌ 비디오 정보를 가져올 수 없습니다: {file_path}")
            video_info = {
                'width': 1920, 'height': 1080, 'codec': 'unknown',
                'duration': 0, 'bitrate': 0
            }

        # 원본 비트레이트를 Mbps로 변환
        orig_mbps = video_info['bitrate'] // 1000000 if video_info['bitrate'] > 0 else 0

        # 비디오 필터 리스트
        vf_filters = []

        # 타겟 해상도 설정
        if target_resolution in self.RESOLUTION_CONFIG:
            res_config = self.RESOLUTION_CONFIG[target_resolution]
            target_height = res_config["height"]
            vf_filters.append(f"scale={res_config['width']}:{res_config['height']}")
        else:
            target_height = video_info['height']

        # 디인터레이싱 필터 추가 (progressive 선택 시)
        if scan_type == "progressive":
            vf_filters.append("yadif=mode=send_frame:parity=auto:deint=all")

        # 해상도 카테고리 판단
        if target_height >= 2160:
            res_category = "4k"
        elif target_height >= 720:
            res_category = "hd"
        else:
            res_category = "sd"

        # 코덱 설정 가져오기
        if target_codec not in self.CODEC_CONFIG:
            return None

        codec_config = self.CODEC_CONFIG[target_codec]

        # 비트레이트 계산 (커스텀 비트레이트가 있으면 사용)
        if custom_video_bitrate:
            target_br = custom_video_bitrate
            max_br = int(target_br * 1.25)  # 커스텀 비트레이트의 125%를 maxrate로 설정
        else:
            default_bitrate = codec_config["bitrates"][res_category]
            target_br = max(orig_mbps, default_bitrate) if orig_mbps > 0 else default_bitrate
            max_br = target_br + codec_config["bitrate_bonus"][res_category]

        # 품질 프리셋 가져오기 (커스텀인 경우 balanced 사용)
        if quality_preset == "custom":
            preset_value = self.QUALITY_PRESETS["balanced"][target_codec]
        else:
            preset_value = self.QUALITY_PRESETS[quality_preset][target_codec]

        # 하드웨어 가속 사용 여부 결정 (fast 프리셋이고 hw_encoder가 있으면 사용)
        use_hw_accel = (
            self.hw_accel_available and
            codec_config.get("hw_encoder") and
            quality_preset == "fast"
        )

        # 명령어 리스트 구성
        if use_hw_accel:
            # 하드웨어 가속 사용 (VideoToolbox - 매우 빠름!)
            cmd_args = [
                "-c:v", codec_config["hw_encoder"],
                "-b:v", f"{target_br}M",
                "-maxrate", f"{max_br}M",
                "-bufsize", f"{max_br * 2}M"
            ]
            print(f"🚀 하드웨어 가속 사용: {codec_config['hw_encoder']}")
        else:
            # 소프트웨어 인코딩
            cmd_args = [
                "-c:v", codec_config["encoder"],
                "-b:v", f"{target_br}M",
                "-maxrate", f"{max_br}M",
                "-bufsize", f"{max_br * 2}M",
                f"-{codec_config['param_name']}", str(preset_value)
            ]

        # 프레임레이트 설정
        if target_fps != "original":
            cmd_args.extend(["-r", target_fps])

        # 비디오 필터 추가
        if vf_filters:
            cmd_args.extend(["-vf", ",".join(vf_filters)])

        return cmd_args
    
    def convert_video(self, input_file, output_file, target_codec, target_resolution, quality_preset, target_fps="original", scan_type="progressive", custom_video_bitrate=None, custom_audio_bitrate=None, progress_callback=None):
        """비디오 변환 실행"""
        try:
            self.conversion_stopped = False

            # 코덱 옵션 생성
            codec_options = self.get_codec_options(input_file, target_codec, target_resolution, quality_preset, target_fps, scan_type, custom_video_bitrate, custom_audio_bitrate)
            if not codec_options:
                return False, f"코덱 옵션 생성 실패 - 파일: {input_file}, 코덱: {target_codec}"

            print(f"🎯 FFmpeg 명령어 옵션: {' '.join(codec_options)}")

            # 출력 디렉토리 생성
            os.makedirs(os.path.dirname(output_file), exist_ok=True)

            # 오디오 코덱 설정 (커스텀 비트레이트가 있으면 재인코딩, 없으면 복사)
            if custom_audio_bitrate:
                audio_options = ['-c:a', 'aac', '-b:a', f'{custom_audio_bitrate}k']
            else:
                audio_options = ['-c:a', 'copy']

            # FFmpeg 명령어 구성 (로컬 바이너리 사용)
            ffmpeg_path = self._get_ffmpeg_path()
            cmd = [ffmpeg_path, '-i', input_file] + codec_options + audio_options + ['-map', '0', output_file, '-y', '-progress', 'pipe:1']

            # 비디오 길이 추출 (진행률 계산용)
            video_info = self.get_video_info(input_file)
            total_duration = video_info['duration'] if video_info else 0

            # FFmpeg 프로세스 시작 (stderr도 STDOUT으로 리다이렉트하여 버퍼 문제 방지)
            self.current_process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                universal_newlines=True,
                bufsize=1
            )

            # 진행률 모니터링
            last_progress_time = time.time()
            stderr_lines = []

            while True:
                if self.conversion_stopped:
                    self.current_process.terminate()
                    return False, "사용자에 의해 중단됨"

                output = self.current_process.stdout.readline()
                if output == '' and self.current_process.poll() is not None:
                    break

                # stderr 출력 저장 (디버깅용)
                if output.strip():
                    stderr_lines.append(output.strip())
                    # 최근 50줄만 유지
                    if len(stderr_lines) > 50:
                        stderr_lines.pop(0)

                if output.strip().startswith('out_time_ms='):
                    try:
                        time_ms = int(output.strip().split('=')[1])
                        time_seconds = time_ms / 1000000

                        if total_duration > 0 and progress_callback:
                            progress = min(time_seconds / total_duration, 1.0)
                            progress_callback(progress, time_seconds, total_duration)
                            last_progress_time = time.time()
                    except Exception as e:
                        print(f"진행률 파싱 중 오류: {e}")

                # 30초 이상 진행률 업데이트가 없으면 경고
                if time.time() - last_progress_time > 30:
                    print(f"⚠️ 30초 동안 진행률 업데이트 없음")
                    last_progress_time = time.time()

            # 프로세스 완료 확인
            return_code = self.current_process.wait()

            if return_code == 0:
                return True, "변환 완료"
            else:
                # 마지막 오류 메시지 출력
                error_msg = '\n'.join(stderr_lines[-10:]) if stderr_lines else "알 수 없는 오류"
                return False, f"FFmpeg 오류: {error_msg}"

        except Exception as e:
            return False, f"변환 중 오류 발생: {str(e)}"
    
    def stop_conversion(self):
        """변환 중단"""
        self.conversion_stopped = True
        if self.current_process and self.current_process.poll() is None:
            try:
                self.current_process.terminate()
                self.current_process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self.current_process.kill()

class YouTubeDownloader:
    """유튜브 다운로더 클래스"""
    
    def __init__(self):
        self.download_process = None
        self.download_stopped = False
        self.base_dir = os.path.dirname(os.path.abspath(__file__))
    
    def _get_yt_dlp_path(self):
        """yt-dlp 경로 찾기 (로컬 bin 우선)"""
        local_yt_dlp = os.path.join(self.base_dir, 'bin', 'yt-dlp')
        if os.path.exists(local_yt_dlp):
            return local_yt_dlp
        return 'yt-dlp'  # 시스템 PATH에서 찾기
    
    def check_yt_dlp(self):
        """yt-dlp 설치 확인"""
        try:
            yt_dlp_path = self._get_yt_dlp_path()
            result = subprocess.run([yt_dlp_path, '--version'], capture_output=True, text=True, timeout=10)
            return result.returncode == 0
        except Exception as e:
            print(f"yt-dlp 설치 확인 오류: {e}")
            return False
    
    def get_video_title_fast(self, url):
        """유튜브 비디오 제목만 빠르게 추출 (큐 추가용)"""
        try:
            yt_dlp_path = self._get_yt_dlp_path()
            cmd = [yt_dlp_path, '--get-title', '--no-warnings', url]
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)

            if result.returncode == 0:
                title = result.stdout.strip()
                return {
                    'title': title if title else 'Unknown',
                    'duration': 0,  # 나중에 다운로드 시 확인
                    'uploader': 'Unknown',
                    'view_count': 0,
                    'upload_date': 'Unknown'
                }
            else:
                print(f"yt-dlp error (returncode {result.returncode}): {result.stderr.strip()}")
                return None
        except subprocess.TimeoutExpired:
            print(f"yt-dlp timeout (30s) fetching: {url}")
            return None
        except Exception as e:
            print(f"비디오 제목 추출 오류: {e}")
            return None

    def get_video_info(self, url):
        """유튜브 비디오 정보 추출 (전체 정보)"""
        try:
            yt_dlp_path = self._get_yt_dlp_path()
            cmd = [yt_dlp_path, '--dump-json', '--no-download', url]
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)

            if result.returncode == 0:
                video_info = json.loads(result.stdout.split('\n')[0])  # 첫 번째 비디오만
                return {
                    'title': video_info.get('title', 'Unknown'),
                    'duration': video_info.get('duration', 0),
                    'uploader': video_info.get('uploader', 'Unknown'),
                    'view_count': video_info.get('view_count', 0),
                    'upload_date': video_info.get('upload_date', 'Unknown')
                }
        except Exception as e:
            print(f"비디오 정보 추출 오류: {e}")
            return None
    
    def download_video(self, url, output_path, progress_callback=None):
        """유튜브 비디오 다운로드"""
        try:
            self.download_stopped = False

            # 다운로드 전 폴더의 기존 파일 목록 저장
            existing_files = set(os.listdir(output_path)) if os.path.exists(output_path) else set()

            # 최고 품질 비디오 + 오디오 다운로드 (해상도 우선)
            yt_dlp_path = self._get_yt_dlp_path()
            cmd = [
                yt_dlp_path,
                '-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/bestvideo+bestaudio/best',  # 최고 해상도 우선
                '--merge-output-format', 'mp4',  # 최종 출력은 MP4로 병합
                '--no-playlist',  # 플레이리스트의 다른 영상 다운로드 방지
                '-o', os.path.join(output_path, '%(title)s.%(ext)s'),
                '--newline',  # 진행률 표시를 위한 개행
                url
            ]

            self.download_process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                universal_newlines=True,
                bufsize=1
            )

            downloaded_file = None

            # 진행률 모니터링
            while True:
                if self.download_stopped:
                    self.download_process.terminate()
                    return False, "사용자에 의해 중단됨", None

                output = self.download_process.stdout.readline()
                if output == '' and self.download_process.poll() is not None:
                    break

                # 디버깅을 위한 출력
                print(f"[yt-dlp] {output.strip()}")

                # 진행률 파싱
                if '[download]' in output and '%' in output:
                    try:
                        # 진행률 추출 (예: [download]  45.2% of 50.2MiB at 1.2MiB/s ETA 00:30)
                        progress_match = re.search(r'(\d+\.?\d*)%', output)
                        if progress_match and progress_callback:
                            progress = float(progress_match.group(1)) / 100
                            progress_callback(progress)
                    except Exception as e:
                        print(f"YouTube 진행률 파싱 오류: {e}")

                # 다운로드 완료된 파일명 추출 (여러 패턴 지원)
                if '[Merger]' in output and 'Merging formats into' in output:
                    try:
                        # [Merger] Merging formats into "filename.mp4"
                        file_match = re.search(r'Merging formats into "([^"]+)"', output)
                        if file_match:
                            downloaded_file = file_match.group(1).strip()
                            print(f"✅ 병합된 파일: {downloaded_file}")
                    except Exception as e:
                        print(f"병합 파일명 추출 오류: {e}")

                elif 'has already been downloaded' in output or 'Destination:' in output:
                    try:
                        # 파일 경로 추출
                        if 'has already been downloaded' in output:
                            # [download] /path/to/file.mp4 has already been downloaded
                            file_match = re.search(r'\[download\] (.+?) has already been downloaded', output)
                            if file_match:
                                downloaded_file = file_match.group(1).strip()
                                print(f"✅ 이미 다운로드된 파일: {downloaded_file}")
                        elif 'Destination:' in output:
                            file_match = re.search(r'Destination: (.+)', output)
                            if file_match:
                                downloaded_file = file_match.group(1).strip()
                                print(f"✅ 다운로드된 파일: {downloaded_file}")
                    except Exception as e:
                        print(f"다운로드 파일명 추출 오류: {e}")

            return_code = self.download_process.wait()

            if return_code == 0:
                # 다운로드된 파일 찾기 (파일명을 못 찾은 경우)
                if not downloaded_file or not os.path.exists(downloaded_file):
                    print("⚠️  파일 경로를 찾을 수 없어서 폴더에서 검색 중...")
                    # 새로 생성된 파일 찾기
                    current_files = set(os.listdir(output_path))
                    new_files = current_files - existing_files

                    # .mp4 파일만 필터링
                    mp4_files = [f for f in new_files if f.endswith('.mp4')]

                    if mp4_files:
                        # 가장 최근에 수정된 파일 선택
                        mp4_files_with_time = [(f, os.path.getmtime(os.path.join(output_path, f))) for f in mp4_files]
                        mp4_files_with_time.sort(key=lambda x: x[1], reverse=True)
                        downloaded_file = os.path.join(output_path, mp4_files_with_time[0][0])
                        print(f"✅ 폴더에서 찾은 파일: {downloaded_file}")

                if downloaded_file and os.path.exists(downloaded_file):
                    return True, "다운로드 완료", downloaded_file
                else:
                    return False, "다운로드 파일을 찾을 수 없음", None
            else:
                return False, "다운로드 실패", None

        except Exception as e:
            return False, f"다운로드 중 오류: {str(e)}", None
    
    def stop_download(self):
        """다운로드 중단"""
        self.download_stopped = True
        if self.download_process and self.download_process.poll() is None:
            try:
                self.download_process.terminate()
                self.download_process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self.download_process.kill()

# 페이지 설정
st.set_page_config(
    page_title="Video Tool v5.0",
    page_icon="🎥",
    layout="wide",
    initial_sidebar_state="collapsed"
)

# 메뉴 버튼 강제 표시 및 Deploy 버튼만 숨김
st.markdown("""
<style>
/* 푸터만 숨김 */
footer {
    visibility: hidden !important;
}

/* 메뉴 버튼 강제 표시 - 모든 가능한 선택자 */
[data-testid="stMainMenu"] {
    display: block !important;
    visibility: visible !important;
    opacity: 1 !important;
    position: fixed !important;
    top: 0.75rem !important;
    right: 1rem !important;
    z-index: 999999 !important;
}

button[data-testid="stMainMenu"] {
    display: block !important;
    visibility: visible !important;
    opacity: 1 !important;
}

.stMainMenu {
    display: block !important;
    visibility: visible !important;
    opacity: 1 !important;
}

/* Deploy 버튼만 숨김 */
.stAppDeployButton,
button[data-testid="stAppDeployButton"] {
    display: none !important;
}

/* 테마 토글 버튼 스타일 */
button[key="theme_toggle"] {
    font-size: 1.5rem !important;
    padding: 0.5rem 1rem !important;
    border-radius: 50% !important;
    border: 1px solid #e5e7eb !important;
    background-color: white !important;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1) !important;
    transition: all 0.2s !important;
}

button[key="theme_toggle"]:hover {
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.15) !important;
    transform: scale(1.05) !important;
}

[data-theme="dark"] button[key="theme_toggle"] {
    background-color: #1f2937 !important;
    border-color: #374151 !important;
}
</style>
""", unsafe_allow_html=True)

# 커스텀 CSS (v5.0 스타일 - 다크모드 지원)
st.markdown("""
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style>
    /* === 전역 설정 === */
    * {
        font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif !important;
    }

    /* 상단 공백 제거 */
    .stApp > header {
        height: 0rem;
    }

    .main .block-container {
        padding-top: 1rem;
        padding-bottom: 0rem;
        padding-left: 3rem;
        padding-right: 3rem;
        max-width: 100%;
    }

    .stApp {
        margin-top: -80px;
        background-color: #f9fafb;
    }

    [data-theme="dark"] .stApp {
        background-color: #030712;
    }

    /* === 다크모드 전역 텍스트 및 요소 === */
    [data-theme="dark"] {
        color-scheme: dark;
        color: #f9fafb !important;
    }

    [data-theme="dark"] p,
    [data-theme="dark"] span,
    [data-theme="dark"] label,
    [data-theme="dark"] h1,
    [data-theme="dark"] h2,
    [data-theme="dark"] h3,
    [data-theme="dark"] h4,
    [data-theme="dark"] h5,
    [data-theme="dark"] h6,
    [data-theme="dark"] div,
    [data-theme="dark"] li,
    [data-theme="dark"] td,
    [data-theme="dark"] th {
        color: #f9fafb !important;
    }

    [data-theme="dark"] .stMarkdown,
    [data-theme="dark"] .stMarkdown p,
    [data-theme="dark"] .stMarkdown span,
    [data-theme="dark"] [data-testid="stMarkdownContainer"],
    [data-theme="dark"] [data-testid="stMarkdownContainer"] p {
        color: #f9fafb !important;
    }

    [data-theme="dark"] .element-container {
        color: #f9fafb !important;
    }

    /* 입력 필드 다크모드 */
    [data-theme="dark"] input,
    [data-theme="dark"] textarea,
    [data-theme="dark"] select,
    [data-theme="dark"] [data-baseweb="select"],
    [data-theme="dark"] [data-baseweb="input"] {
        background-color: #1f2937 !important;
        color: #f9fafb !important;
        border-color: #374151 !important;
    }

    /* Disabled 인풋 필드 글씨색 밝게 */
    [data-theme="dark"] input:disabled,
    [data-theme="dark"] textarea:disabled {
        color: #d1d5db !important;
        -webkit-text-fill-color: #d1d5db !important;
        opacity: 1 !important;
    }

    [data-theme="dark"] input::placeholder,
    [data-theme="dark"] textarea::placeholder {
        color: #d1d5db !important;
    }

    [data-theme="dark"] input:focus,
    [data-theme="dark"] textarea:focus,
    [data-theme="dark"] select:focus {
        border-color: #60a5fa !important;
        box-shadow: 0 0 0 1px #60a5fa !important;
    }

    /* 셀렉트박스 다크모드 */
    [data-theme="dark"] [data-baseweb="select"] > div {
        background-color: #1f2937 !important;
        border-color: #374151 !important;
    }

    /* 셀렉트박스 화살표 아이콘 밝게 */
    [data-theme="dark"] [data-baseweb="select"] svg {
        color: #f9fafb !important;
        fill: #f9fafb !important;
    }

    /* 셀렉트박스 텍스트 밝게 */
    [data-theme="dark"] [data-baseweb="select"] > div > div {
        color: #f9fafb !important;
    }

    [data-theme="dark"] [data-baseweb="popover"] {
        background-color: #1f2937 !important;
    }

    [data-theme="dark"] [data-baseweb="menu"] {
        background-color: #1f2937 !important;
    }

    [data-theme="dark"] [role="option"] {
        background-color: #1f2937 !important;
        color: #f9fafb !important;
    }

    [data-theme="dark"] [role="option"]:hover {
        background-color: #374151 !important;
    }

    /* 파일 업로더 다크모드 */
    [data-theme="dark"] [data-testid="stFileUploader"] {
        background-color: #1f2937 !important;
        border-color: #374151 !important;
    }

    [data-theme="dark"] [data-testid="stFileUploader"] section {
        background-color: #1f2937 !important;
        border-color: #374151 !important;
    }

    /* 체크박스 다크모드 */
    [data-theme="dark"] [data-testid="stCheckbox"] label {
        color: #f9fafb !important;
    }

    /* 탭 패널 다크모드 */
    [data-theme="dark"] [data-testid="stTabContent"] {
        background-color: #030712 !important;
    }

    /* 익스팬더 다크모드 */
    [data-theme="dark"] [data-testid="stExpander"] {
        background-color: #1f2937 !important;
        border-color: #374151 !important;
    }

    [data-theme="dark"] [data-testid="stExpanderDetails"] {
        background-color: #111827 !important;
    }

    /* 알림 메시지 다크모드 */
    [data-theme="dark"] [data-testid="stAlert"] {
        background-color: #1f2937 !important;
        color: #f9fafb !important;
    }

    /* 코드 블록 다크모드 */
    [data-theme="dark"] code {
        background-color: #1f2937 !important;
        color: #f9fafb !important;
    }

    [data-theme="dark"] pre {
        background-color: #1f2937 !important;
        border-color: #374151 !important;
    }

    /* Description 및 서브텍스트 다크모드 */
    [data-theme="dark"] [data-testid="stText"] {
        color: #f9fafb !important;
    }

    [data-theme="dark"] small {
        color: #9ca3af !important;
    }

    /* 구분선 다크모드 */
    [data-theme="dark"] hr {
        border-color: #374151 !important;
    }

    /* 메트릭 다크모드 */
    [data-theme="dark"] [data-testid="stMetric"] {
        background-color: #1f2937 !important;
        border-color: #374151 !important;
    }

    [data-theme="dark"] [data-testid="stMetricLabel"] {
        color: #9ca3af !important;
    }

    [data-theme="dark"] [data-testid="stMetricValue"] {
        color: #f9fafb !important;
    }

    /* 컬럼 다크모드 */
    [data-theme="dark"] [data-testid="column"] {
        background-color: transparent !important;
    }

    /* Tooltip 다크모드 */
    [data-theme="dark"] [data-testid="stTooltipIcon"] {
        color: #f9fafb !important;
    }
    [data-theme="dark"] [data-baseweb="tooltip"],
    [data-theme="dark"] div[role="tooltip"],
    [data-theme="dark"] .stTooltipContent {
        background-color: #1f2937 !important;
        color: #f9fafb !important;
        border: 1px solid #374151 !important;
    }
    [data-theme="dark"] [data-baseweb="tooltip"] * {
        color: #f9fafb !important;
    }

    /* === 헤더 스타일 (v5.0) === */
    .main-header {
        text-align: center;
        background: linear-gradient(90deg, #ff4b4b, #f97316);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
        font-size: 2.5rem;
        font-weight: 700;
        letter-spacing: -0.025em;
        margin-bottom: 0.5rem;
        margin-top: 0rem;
    }

    /* === 카드/박스 스타일 (v5.0) === */
    .feature-box {
        background-color: white;
        color: #111827;
        padding: 1.5rem;
        border-radius: 0.5rem;
        border: 1px solid #e5e7eb;
        margin: 1rem 0;
        box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.1);
        transition: all 0.2s;
    }

    .feature-box:hover {
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
    }

    .feature-box h4 {
        color: #111827;
        font-weight: 600;
        margin-bottom: 0.75rem;
    }

    .feature-box ul {
        color: #374151;
        margin: 0;
        padding-left: 1.5rem;
    }

    .feature-box li {
        margin-bottom: 0.5rem;
    }

    /* 다크모드 카드 */
    [data-theme="dark"] .feature-box {
        background-color: #1f2937;
        color: white;
        border-color: #374151;
    }

    [data-theme="dark"] .feature-box h4 {
        color: white;
    }

    [data-theme="dark"] .feature-box ul {
        color: #d1d5db;
    }

    /* === 프로그레스바 (v5.0 스타일) === */
    .stProgress > div > div > div > div {
        background: linear-gradient(90deg, #ff4b4b, #ff3333);
        border-radius: 9999px;
        height: 0.625rem;
    }

    /* === 변환 상태 박스 === */
    .conversion-status {
        background-color: #f3f4f6;
        padding: 1rem;
        border-radius: 0.5rem;
        border: 1px solid #e5e7eb;
    }

    [data-theme="dark"] .conversion-status {
        background-color: #1f2937;
        border-color: #374151;
        color: #e5e7eb;
    }

    /* === 파일 리스트 스타일 (v5.0) === */
    div[data-testid="stHorizontalBlock"] {
        gap: 0.5rem;
        align-items: center !important;
    }

    div[data-testid="column"] > div {
        padding-top: 0.1rem !important;
        padding-bottom: 0.1rem !important;
    }

    div[data-testid="stHorizontalBlock"]:has(.stCheckbox) {
        display: flex !important;
        align-items: center !important;
        min-height: 3rem !important;
        margin: 0 -1rem !important;
        padding-left: 1rem !important;
        padding-right: 1rem !important;
        border-bottom: 1px solid #f3f4f6;
        transition: all 0.2s;
    }

    div[data-testid="stHorizontalBlock"]:has(.stCheckbox):hover {
        background-color: rgba(243, 244, 246, 0.5) !important;
    }

    [data-theme="dark"] div[data-testid="stHorizontalBlock"]:has(.stCheckbox) {
        border-bottom-color: #374151;
    }

    [data-theme="dark"] div[data-testid="stHorizontalBlock"]:has(.stCheckbox):hover {
        background-color: rgba(55, 65, 81, 0.3) !important;
    }

    /* 각 컬럼을 flexbox 중앙 정렬 */
    div[data-testid="stHorizontalBlock"]:has(.stCheckbox) > div[data-testid="column"] {
        display: flex !important;
        align-items: center !important;
        height: 100% !important;
    }

    /* stVerticalBlock을 중앙 정렬 */
    div[data-testid="stHorizontalBlock"]:has(.stCheckbox) div[data-testid="stVerticalBlock"] {
        display: flex !important;
        flex-direction: column !important;
        justify-content: center !important;
        align-items: flex-start !important;
        min-height: 2.2rem !important;
    }

    /* 체크박스 컬럼만 가운데 정렬 */
    div[data-testid="stHorizontalBlock"]:has(.stCheckbox) > div[data-testid="column"]:first-child div[data-testid="stVerticalBlock"] {
        align-items: center !important;
    }

    /* p 태그의 모든 부모 컨테이너들도 높이 맞추기 */
    div[data-testid="stHorizontalBlock"]:has(.stCheckbox) div[data-testid="stVerticalBlock"] > div {
        display: flex !important;
        flex-direction: column !important;
        justify-content: center !important;
        min-height: 2.2rem !important;
    }

    /* 모든 p 태그를 정확히 중앙 정렬 */
    div[data-testid="stHorizontalBlock"]:has(.stCheckbox) p {
        margin: 0 !important;
        padding: 0 !important;
        line-height: 2.2rem !important;
    }

    /* 체크박스 위젯도 정확히 중앙 */
    div[data-testid="stHorizontalBlock"]:has(.stCheckbox) .stCheckbox {
        margin: 0 !important;
        padding: 0 !important;
    }

    /* === 버튼 스타일 (v5.0) === */
    button[kind="primary"] {
        background-color: #3b82f6 !important;
        border-color: #3b82f6 !important;
        color: white !important;
        font-weight: 500 !important;
        border-radius: 0.375rem !important;
        transition: all 0.2s !important;
    }

    button[kind="primary"]:hover {
        background-color: #2563eb !important;
        border-color: #2563eb !important;
    }

    button[kind="secondary"] {
        background-color: white !important;
        border: 1px solid #d1d5db !important;
        color: #374151 !important;
        font-weight: 500 !important;
        border-radius: 0.375rem !important;
        transition: all 0.2s !important;
    }

    button[kind="secondary"]:hover {
        background-color: #f9fafb !important;
        border-color: #9ca3af !important;
    }

    [data-theme="dark"] button[kind="secondary"] {
        background-color: #1f2937 !important;
        border-color: #4b5563 !important;
        color: #e5e7eb !important;
    }

    [data-theme="dark"] button[kind="secondary"]:hover {
        background-color: #374151 !important;
    }

    /* 헤더 행 스타일 - 스프레드시트처럼 */
    div[data-testid="column"]:has(button[key*="sort"]),
    div[data-testid="column"]:has(.st-key-toggle_all_header) {
        background-color: rgba(240, 242, 246, 0.5) !important;
        border-bottom: 2px solid rgba(224, 224, 224, 0.3) !important;
        padding: 0.75rem !important;
    }

    [data-theme="dark"] div[data-testid="column"]:has(button[key*="sort"]),
    [data-theme="dark"] div[data-testid="column"]:has(.st-key-toggle_all_header) {
        background-color: rgba(38, 39, 48, 0.5) !important;
        border-bottom: 2px solid rgba(68, 68, 68, 0.3) !important;
    }

    /* 정렬 헤더 버튼 스타일 - 테두리 완전 제거 */
    button[key="sort_name"],
    button[key="sort_size"],
    button[key="sort_date"] {
        border: none !important;
        background-color: transparent !important;
        box-shadow: none !important;
        outline: none !important;
        padding: 0.75rem !important;
        font-weight: 600 !important;
        cursor: pointer !important;
    }

    button[key="sort_name"]:hover,
    button[key="sort_size"]:hover,
    button[key="sort_date"]:hover {
        background-color: rgba(78, 205, 196, 0.15) !important;
        border: none !important;
        cursor: pointer !important;
    }

    button[key="sort_name"]:focus,
    button[key="sort_size"]:focus,
    button[key="sort_date"]:focus {
        border: none !important;
        box-shadow: none !important;
        outline: none !important;
    }

    /* 헤더 체크박스 커서 */
    .st-key-toggle_all_header {
        cursor: pointer !important;
    }

    /* === 탭 스타일 (v5.0) === */
    .stTabs [data-baseweb="tab-list"] {
        gap: 2rem;
        border-bottom: 2px solid #e5e7eb;
    }

    [data-theme="dark"] .stTabs [data-baseweb="tab-list"] {
        border-bottom-color: #374151;
    }

    .stTabs [data-baseweb="tab"] {
        height: 3rem;
        padding: 0 1rem;
        background-color: transparent;
        border: none;
        color: #6b7280;
        font-weight: 500;
        border-bottom: 2px solid transparent;
        margin-bottom: -2px;
    }

    .stTabs [data-baseweb="tab"]:hover {
        color: #111827;
        background-color: transparent;
    }

    [data-theme="dark"] .stTabs [data-baseweb="tab"] {
        color: #9ca3af;
    }

    [data-theme="dark"] .stTabs [data-baseweb="tab"]:hover {
        color: white;
    }

    .stTabs [aria-selected="true"] {
        color: #ff4b4b !important;
        border-bottom-color: #ff4b4b !important;
        font-weight: 600 !important;
    }

    [data-theme="dark"] .stTabs [aria-selected="true"] {
        color: #ff4b4b !important;
    }
</style>
""", unsafe_allow_html=True)

# 공통 함수들
def open_folder_dialog():
    """플랫폼별 폴더 선택 다이얼로그 (macOS는 osascript, 기타는 수동 입력)"""
    import sys

    # macOS에서만 osascript 사용
    if sys.platform == 'darwin':
        try:
            apple_script = '''
            tell application "System Events"
                activate
                set selectedFolder to choose folder with prompt "Select folder containing video files"
                return POSIX path of selectedFolder
            end tell
            '''

            result = subprocess.run(
                ['osascript', '-e', apple_script],
                capture_output=True,
                text=True,
                timeout=60
            )

            if result.returncode == 0:
                folder_selected = result.stdout.strip()
                if folder_selected and os.path.exists(folder_selected):
                    st.session_state['selected_folder_path'] = folder_selected
                    scan_folder_files(folder_selected)
                    return folder_selected
            return None
        except Exception as e:
            st.error(f"Folder selection error: {e}")
            return None
    else:
        # macOS가 아닌 환경에서는 수동 입력 사용
        st.info("💡 Non-macOS environment: Please enter the folder path manually below.")
        return None

def open_folder_dialog():
    """폴더 선택 다이얼로그 (macOS 전용)"""
    import sys

    if sys.platform == 'darwin':
        try:
            apple_script = '''
            tell application "System Events"
                activate
                set selectedFolder to choose folder with prompt "Select folder containing video files"
                return POSIX path of selectedFolder
            end tell
            '''

            result = subprocess.run(
                ['osascript', '-e', apple_script],
                capture_output=True,
                text=True,
                timeout=60
            )

            if result.returncode == 0:
                folder_path = result.stdout.strip()
                if folder_path and os.path.exists(folder_path):
                    st.session_state['selected_folder_path'] = folder_path
                    scan_folder_files(folder_path)
                    return folder_path
            return None
        except Exception as e:
            st.error(f"Folder selection error: {e}")
            return None
    return None

def open_file_dialog():
    """파일 선택 다이얼로그 (macOS 전용)"""
    import sys

    if sys.platform == 'darwin':
        try:
            apple_script = '''
            tell application "System Events"
                activate
                set selectedFiles to choose file with prompt "Select video files" with multiple selections allowed
                set filePaths to {}
                repeat with aFile in selectedFiles
                    set end of filePaths to POSIX path of aFile
                end repeat
                return filePaths
            end tell
            '''

            result = subprocess.run(
                ['osascript', '-e', apple_script],
                capture_output=True,
                text=True,
                timeout=60
            )

            if result.returncode == 0:
                files_str = result.stdout.strip()
                if files_str:
                    file_paths = [f.strip() for f in files_str.split(', ') if f.strip()]

                    # 비디오 파일만 필터링
                    video_extensions = ['.mp4', '.avi', '.mov', '.mkv', '.wmv', '.flv', '.webm', '.m4v', '.mpg', '.mpeg', '.3gp']
                    valid_files = [f for f in file_paths if any(f.lower().endswith(ext) for ext in video_extensions) and os.path.exists(f)]

                    if valid_files:
                        st.session_state['video_files_list'] = valid_files
                        st.session_state['file_selection_state'] = {file: True for file in valid_files}
                        st.session_state['selected_folder_path'] = os.path.dirname(valid_files[0])
                        return valid_files
            return None
        except Exception as e:
            st.error(f"File selection error: {e}")
            return None
    return None

def scan_folder_files(folder_path):
    """선택된 폴더에서 비디오 파일 스캔"""
    video_extensions = ['.mp4', '.avi', '.mov', '.mkv', '.wmv', '.flv', '.webm', '.m4v', '.mpg', '.mpeg', '.3gp']
    video_files = []
    
    try:
        for file in os.listdir(folder_path):
            if any(file.lower().endswith(ext) for ext in video_extensions):
                video_files.append(os.path.join(folder_path, file))
        
        st.session_state['video_files_list'] = video_files
        st.session_state['file_selection_state'] = {file: True for file in video_files}
        
    except Exception as e:
        st.error(f"Folder scan error: {e}")

def convert_videos_realtime(selected_files, target_codec, target_resolution, quality_preset, selected_fps="original", selected_scan="progressive", custom_video_br=None, custom_audio_br=None):
    """실시간 비디오 변환 함수"""
    total_files = len(selected_files)
    
    # 출력 폴더 생성
    output_folder = f"converted_{target_codec}"
    current_dir = st.session_state.get('selected_folder_path', os.getcwd())
    output_path = os.path.join(current_dir, output_folder)
    
    st.markdown(f"### 🎬 Conversion Progress")
    st.info(f"📂 Output folder: {output_path}")
    
    overall_progress = st.progress(0)
    current_file_info = st.empty()
    current_file_progress = st.progress(0)
    conversion_log = st.empty()
    
    successful_conversions = 0
    failed_conversions = 0
    
    for file_idx, input_file in enumerate(selected_files):
        if not st.session_state.get('conversion_running', False):
            break
            
        file_name = os.path.basename(input_file)
        base_name = os.path.splitext(file_name)[0]
        
        # 출력 파일명 생성
        if target_resolution != "original":
            output_filename = f"{base_name}_{target_codec}_{target_resolution}.mp4"
        else:
            output_filename = f"{base_name}_{target_codec}.mp4"
        
        output_file = os.path.join(output_path, output_filename)
        
        # 현재 파일 정보 표시
        current_file_info.markdown(f"**📁 [{file_idx + 1}/{total_files}] 변환 중:** `{file_name}`")
        
        # 진행률 콜백 함수 (예상 시간 포함)
        conversion_start_time = time.time()

        def progress_callback(progress, current_time, total_time):
            current_file_progress.progress(progress)
            min_current = int(current_time // 60)
            sec_current = int(current_time % 60)
            min_total = int(total_time // 60)
            sec_total = int(total_time % 60)

            # 예상 남은 시간 계산
            if progress > 0.01:  # 1% 이상 진행되었을 때만 계산
                elapsed = time.time() - conversion_start_time
                estimated_total = elapsed / progress
                remaining = int(estimated_total - elapsed)

                if remaining > 0:
                    min_remaining = remaining // 60
                    sec_remaining = remaining % 60
                    conversion_log.text(
                        f"⏱️ 진행률: {progress*100:.1f}% | {min_current:02d}:{sec_current:02d} / {min_total:02d}:{sec_total:02d} | "
                        f"예상 남은 시간: {min_remaining}분 {sec_remaining}초"
                    )
                else:
                    conversion_log.text(f"⏱️ 진행률: {progress*100:.1f}% | {min_current:02d}:{sec_current:02d} / {min_total:02d}:{sec_total:02d}")
            else:
                conversion_log.text(f"⏱️ 진행률: {progress*100:.1f}% | {min_current:02d}:{sec_current:02d} / {min_total:02d}:{sec_total:02d}")
        
        # 현재 파일의 정보 표시
        try:
            video_info = st.session_state['converter'].get_video_info(input_file)
            if video_info:
                width, height = video_info['width'], video_info['height']
                codec = video_info['codec']
                duration_min = int(video_info['duration'] // 60)
                duration_sec = int(video_info['duration'] % 60)
                bitrate_mbps = video_info['bitrate'] // 1000000 if video_info['bitrate'] > 0 else 0
                
                st.write(f"📺 Resolution: {width}x{height} | Codec: {codec} | Duration: {duration_min:02d}:{duration_sec:02d} | Bitrate: {bitrate_mbps}Mbps")
        except Exception as e:
            print(f"비디오 정보 표시 오류: {e}")
        
        # 변환 실행
        start_time = time.time()
        success, message = st.session_state['converter'].convert_video(
            input_file, output_file, target_codec, target_resolution, quality_preset, selected_fps, selected_scan, custom_video_br, custom_audio_br, progress_callback
        )
        end_time = time.time()
        
        if success:
            successful_conversions += 1
            elapsed_time = int(end_time - start_time)
            st.success(f"✅ Conversion complete: `{output_filename}` (Duration: {elapsed_time}s)")
        else:
            failed_conversions += 1
            st.error(f"❌ Conversion failed: `{file_name}` - {message}")
        
        # 전체 진행률 업데이트
        overall_progress.progress((file_idx + 1) / total_files)
        
        # 잠깐 대기
        time.sleep(0.1)
    
    # 변환 완료
    st.session_state['conversion_running'] = False
    current_file_info.empty()
    current_file_progress.empty()
    conversion_log.empty()
    
    if successful_conversions > 0:
        st.success(f"🎉 Conversion complete! Success: {successful_conversions}, Failed: {failed_conversions}")
        st.balloons()
    else:
        st.error("❌ All conversions failed.")

def batch_download_and_convert(selected_items):
    """유튜브 배치 다운로드 + 변환 함수"""
    total_videos = len(selected_items)

    st.markdown(f"### 🎬 Batch Download + Conversion Progress ({total_videos} videos)")

    # 저장 경로 설정
    save_path = st.session_state.get('yt_save_folder_path', os.path.join(os.getcwd(), "youtube_downloads"))
    os.makedirs(save_path, exist_ok=True)

    st.info(f"📂 Save location: {save_path}")

    # 전체 진행률
    overall_progress = st.progress(0)
    current_video_info = st.empty()

    # 개별 비디오 진행률
    download_progress = st.progress(0)
    conversion_progress = st.progress(0)
    status_text = st.empty()

    successful_count = 0
    failed_count = 0

    for video_idx, item in enumerate(selected_items):
        if not st.session_state.get('yt_download_running', False):
            break

        url = item['url']
        info = item['info']
        settings = item['settings']

        # 현재 비디오 정보 표시
        current_video_info.markdown(f"**📥 [{video_idx + 1}/{total_videos}] {info['title']}**")

        # 다운로드 진행률 콜백
        def download_progress_callback(progress):
            overall = (video_idx + progress * 0.5) / total_videos
            overall_progress.progress(overall)
            download_progress.progress(progress)

        # 다운로드 실행
        status_text.markdown("**📥 Downloading from YouTube...**")
        success, message, downloaded_file = st.session_state['yt_downloader'].download_video(
            url, save_path, download_progress_callback
        )

        if not success:
            st.error(f"❌ Download failed: {info['title']} - {message}")
            failed_count += 1
            overall_progress.progress((video_idx + 1) / total_videos)
            continue

        st.success(f"✅ Downloaded: {os.path.basename(downloaded_file)}")

        # 다운로드 성공 시 큐의 해당 아이템 정보 업데이트
        for queue_item in st.session_state['yt_queue']:
            if queue_item['url'] == url:
                # 전체 정보 가져오기
                full_info = st.session_state['yt_downloader'].get_video_info(url)
                if full_info:
                    queue_item['info'] = full_info
                break

        # Download Only 모드면 변환 건너뛰기
        if settings.get('download_only', False):
            st.info("📥 Download Only mode - Skipping conversion")
            successful_count += 1
            overall_progress.progress((video_idx + 1) / total_videos)
            download_progress.progress(0)
            continue

        # 변환 필요 여부 확인
        video_info = st.session_state['converter'].get_video_info(downloaded_file)
        current_codec = video_info['codec'] if video_info else 'unknown'

        needs_conversion = (
            current_codec != settings['codec'] or
            settings['resolution'] != "original" or
            settings['fps'] != "original" or
            settings['quality'] == "custom"
        )

        if needs_conversion:
            status_text.markdown("**🎬 Converting video...**")

            # 출력 파일명 생성
            base_name = os.path.splitext(os.path.basename(downloaded_file))[0]
            if settings['resolution'] != "original":
                output_filename = f"{base_name}_{settings['codec']}_{settings['resolution']}.mp4"
            else:
                output_filename = f"{base_name}_{settings['codec']}.mp4"

            output_file = os.path.join(save_path, output_filename)

            # 변환 진행률 콜백
            def conversion_progress_callback(progress, current_time, total_time):
                overall = (video_idx + 0.5 + progress * 0.5) / total_videos
                overall_progress.progress(overall)
                conversion_progress.progress(progress)

                min_current = int(current_time // 60)
                sec_current = int(current_time % 60)
                min_total = int(total_time // 60)
                sec_total = int(total_time % 60)

                status_text.markdown(f"**🎬 Converting: {progress*100:.1f}% | {min_current:02d}:{sec_current:02d} / {min_total:02d}:{sec_total:02d}**")

            # 변환 실행
            conversion_success, conversion_message = st.session_state['converter'].convert_video(
                downloaded_file,
                output_file,
                settings['codec'],
                settings['resolution'],
                settings['quality'],
                settings['fps'],
                settings['scan'],
                settings['custom_video_br'],
                settings['custom_audio_br'],
                conversion_progress_callback
            )

            if conversion_success:
                st.success(f"✅ Converted: {output_filename}")
                successful_count += 1

                # 원본 파일 삭제
                try:
                    os.remove(downloaded_file)
                except Exception as e:
                    print(f"원본 파일 삭제 실패: {e}")
            else:
                st.error(f"❌ Conversion failed: {info['title']} - {conversion_message}")
                failed_count += 1
        else:
            st.info(f"ℹ️ Already desired format. Skipping conversion.")
            successful_count += 1

        # 전체 진행률 업데이트
        overall_progress.progress((video_idx + 1) / total_videos)
        download_progress.progress(0)
        conversion_progress.progress(0)

    # 완료
    st.session_state['yt_download_running'] = False
    current_video_info.empty()
    download_progress.empty()
    conversion_progress.empty()
    status_text.empty()
    overall_progress.empty()

    # 배치 완료 후 큐 비우기
    st.session_state['yt_queue'] = []
    st.session_state['yt_queue_selection'] = {}

    if successful_count > 0:
        st.success(f"🎉 Batch operation completed! Success: {successful_count}, Failed: {failed_count}")
        st.balloons()
    else:
        st.error("❌ All operations failed.")

def download_and_convert_youtube(url, target_codec, target_resolution, quality_preset, target_fps="original", target_scan="progressive", custom_video_br=None, custom_audio_br=None, download_only=False):
    """유튜브 다운로드 + 변환 함수"""

    if download_only:
        st.markdown("### 📥 YouTube Download Progress")
    else:
        st.markdown("### 📥 YouTube Download + Conversion Progress")
    
    # 저장 경로 설정
    save_path = st.session_state.get('yt_save_folder_path', os.path.join(os.getcwd(), "youtube_downloads"))
    os.makedirs(save_path, exist_ok=True)
    
    st.info(f"📂 Save location: {save_path}")
    
    # 진행률 표시
    download_progress = st.progress(0)
    status_text = st.empty()
    conversion_progress = st.progress(0)
    
    # 1단계: 다운로드
    status_text.markdown("**📥 1단계: 유튜브에서 다운로드 중...**")
    
    def download_progress_callback(progress):
        download_progress.progress(progress * 0.5)  # 전체의 50%까지
    
    success, message, downloaded_file = st.session_state['yt_downloader'].download_video(
        url, save_path, download_progress_callback
    )
    
    if not success:
        st.session_state['yt_download_running'] = False
        download_progress.empty()
        conversion_progress.empty()
        status_text.empty()
        st.error(f"❌ Download failed: {message}")
        return
    
    download_progress.progress(0.5)
    st.success(f"✅ Download complete: {os.path.basename(downloaded_file)}")

    # Download Only 모드면 변환 건너뛰기
    if download_only:
        download_progress.progress(1.0)
        st.session_state['yt_download_running'] = False
        download_progress.empty()
        conversion_progress.empty()
        status_text.empty()

        st.success(f"🎉 Download completed! File saved to: `{downloaded_file}`")
        st.balloons()
        return

    # 2단계: 변환 (필요한 경우만)
    if downloaded_file:
        # 현재 코덱 확인
        video_info = st.session_state['converter'].get_video_info(downloaded_file)
        current_codec = video_info['codec'] if video_info else 'unknown'
        
        # 변환이 필요한지 확인
        needs_conversion = (
            current_codec != target_codec or 
            target_resolution != "original"
        )
        
        if needs_conversion:
            status_text.markdown("**🎬 2단계: 비디오 변환 중...**")
            
            # 출력 파일명 생성
            base_name = os.path.splitext(os.path.basename(downloaded_file))[0]
            if target_resolution != "original":
                output_filename = f"{base_name}_{target_codec}_{target_resolution}.mp4"
            else:
                output_filename = f"{base_name}_{target_codec}.mp4"
            
            output_file = os.path.join(save_path, output_filename)
            
            # 변환 진행률 콜백
            def conversion_progress_callback(progress, current_time, total_time):
                overall_progress = 0.5 + (progress * 0.5)  # 50%부터 100%까지
                download_progress.progress(overall_progress)
                conversion_progress.progress(progress)
                
                min_current = int(current_time // 60)
                sec_current = int(current_time % 60)
                min_total = int(total_time // 60)
                sec_total = int(total_time % 60)
                
                status_text.markdown(f"**🎬 변환 진행률: {progress*100:.1f}% | {min_current:02d}:{sec_current:02d} / {min_total:02d}:{sec_total:02d}**")
            
            # 변환 실행
            conversion_success, conversion_message = st.session_state['converter'].convert_video(
                downloaded_file, output_file, target_codec, target_resolution, quality_preset, target_fps, target_scan, custom_video_br, custom_audio_br, conversion_progress_callback
            )
            
            if conversion_success:
                st.success(f"✅ Conversion complete: {output_filename}")
                
                # 원본 파일 삭제 여부 확인
                if st.checkbox("Delete original downloaded file", value=True):
                    try:
                        os.remove(downloaded_file)
                        st.info("🗑️ Original file has been deleted.")
                    except Exception as e:
                        st.warning(f"⚠️ Failed to delete original file: {e}")
                
                final_file = output_file
            else:
                st.error(f"❌ Conversion failed: {conversion_message}")
                final_file = downloaded_file
        else:
            download_progress.progress(1.0)
            st.info("ℹ️ Already the desired codec and resolution. Skipping conversion.")
            final_file = downloaded_file
        
        # 완료
        st.session_state['yt_download_running'] = False
        download_progress.empty()
        conversion_progress.empty()
        status_text.empty()

        st.success(f"🎉 All tasks completed! File saved to: `{final_file}`")
        st.balloons()

# 테마 토글 초기화
if 'theme_mode' not in st.session_state:
    st.session_state['theme_mode'] = 'light'

# 테마 적용 스크립트 (components.html 사용)
theme_html = f"""
<script>
(function() {{
    const theme = '{st.session_state['theme_mode']}';
    console.log('VideoTool: Applying theme:', theme);

    // 테마 적용 함수
    const applyTheme = () => {{
        try {{
            // 메인 앱 요소 찾기
            const stApp = window.parent.document.querySelector('[data-testid="stApp"]');
            if (stApp) {{
                stApp.setAttribute('data-theme', theme);
                console.log('VideoTool: Theme applied to stApp:', theme);
            }} else {{
                console.warn('VideoTool: stApp element not found');
            }}

            // body에도 적용
            const body = window.parent.document.body;
            if (body) {{
                body.setAttribute('data-theme', theme);
                console.log('VideoTool: Theme applied to body:', theme);
            }}

            // html에도 적용
            const html = window.parent.document.documentElement;
            if (html) {{
                html.setAttribute('data-theme', theme);
                console.log('VideoTool: Theme applied to html:', theme);
            }}
        }} catch (e) {{
            console.error('VideoTool: Error applying theme:', e);
        }}
    }};

    // 즉시 적용
    applyTheme();

    // 100ms 후 재적용 (DOM 로드 지연 대비)
    setTimeout(applyTheme, 100);

    // 500ms 후 재적용 (추가 안전장치)
    setTimeout(applyTheme, 500);

    // DOM 변경 감지하여 재적용
    try {{
        const observer = new MutationObserver(() => {{
            applyTheme();
        }});

        if (window.parent.document.body) {{
            observer.observe(window.parent.document.body, {{
                childList: true,
                subtree: false,
                attributes: false
            }});
        }}
    }} catch (e) {{
        console.error('VideoTool: Error setting up observer:', e);
    }}
}})();
</script>
"""
components.html(theme_html, height=0)

# 테마 토글 버튼 스타일
st.markdown(f"""
<style>
.theme-toggle-container {{
    position: fixed;
    top: 3.5rem;
    right: 4.5rem;
    z-index: 999999;
}}
/* 테마 토글 버튼 가운데 정렬 */
button[kind="secondary"] p {{
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
    line-height: 1 !important;
}}
</style>
<div class="theme-toggle-container">
</div>
""", unsafe_allow_html=True)

# 테마 토글 버튼 (우측 상단 고정)
st.markdown("""
<style>
/* 토글 버튼 컨테이너를 우측 상단에 고정 */
.st-key-theme_toggle {
    position: fixed !important;
    top: 0.75rem !important;
    right: 3.5rem !important;
    z-index: 999999 !important;
}

/* 토글 버튼 스타일 */
.st-key-theme_toggle button {
    background-color: transparent !important;
    border: 1px solid #e5e7eb !important;
    border-radius: 0.375rem !important;
    padding: 0.25rem 0.5rem !important;
    font-size: 1.25rem !important;
}

[data-theme="dark"] .st-key-theme_toggle button {
    border-color: #374151 !important;
}

.st-key-theme_toggle button:hover {
    background-color: #f3f4f6 !important;
}

[data-theme="dark"] .st-key-theme_toggle button:hover {
    background-color: #1f2937 !important;
}
</style>
""", unsafe_allow_html=True)

# 현재 테마에 따라 아이콘 표시 (light mode = moon, dark mode = sun)
theme_icon = "☀" if st.session_state['theme_mode'] == 'dark' else "☾"
if st.button(theme_icon, key="theme_toggle", help="Toggle Light/Dark Mode"):
    st.session_state['theme_mode'] = 'dark' if st.session_state['theme_mode'] == 'light' else 'light'
    st.rerun()

# 진행 중 경고 표시
if st.session_state.get('conversion_running', False) or st.session_state.get('yt_download_running', False):
    st.warning("⚠️ **Conversion/Download in progress.** Please do not switch tabs or refresh the page until it's complete.")

# 메인 헤더 (v5.0 스타일)
st.markdown('''
<div style="text-align: center; margin-bottom: 2rem;">
    <h1 class="main-header">🎥 Video Tool v5.0</h1>
    <p style="color: #6b7280; font-size: 0.875rem; font-weight: 500; margin-top: -0.5rem;">
        Video Conversion & YouTube Download Tool
    </p>
</div>
''', unsafe_allow_html=True)

# 탭 아이콘 CSS 추가
st.markdown("""
<style>
/* Video Conversion 탭 아이콘 */
button[data-baseweb="tab"]:nth-child(1)::before {
    content: '';
    display: inline-block;
    width: 16px;
    height: 16px;
    margin-right: 6px;
    vertical-align: middle;
    background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="2" width="20" height="20" rx="2.18" ry="2.18"></rect><line x1="7" y1="2" x2="7" y2="22"></line><line x1="17" y1="2" x2="17" y2="22"></line><line x1="2" y1="12" x2="22" y2="12"></line><line x1="2" y1="7" x2="7" y2="7"></line><line x1="2" y1="17" x2="7" y2="17"></line><line x1="17" y1="17" x2="22" y2="17"></line><line x1="17" y1="7" x2="22" y2="7"></line></svg>');
    background-size: contain;
    background-repeat: no-repeat;
}

/* YouTube Download 탭 아이콘 */
button[data-baseweb="tab"]:nth-child(2)::before {
    content: '';
    display: inline-block;
    width: 16px;
    height: 16px;
    margin-right: 6px;
    vertical-align: middle;
    background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg>');
    background-size: contain;
    background-repeat: no-repeat;
}

/* 다크모드에서 탭 아이콘 색상 조정 */
[data-theme="dark"] button[data-baseweb="tab"]:nth-child(1)::before {
    filter: invert(1) brightness(1.2);
}

[data-theme="dark"] button[data-baseweb="tab"]:nth-child(2)::before {
    filter: invert(1) brightness(1.2);
}
</style>
""", unsafe_allow_html=True)

# 탭 생성
tab1, tab2 = st.tabs(["Video Conversion", "YouTube Download"])

# Tab 1: Local File Conversion
with tab1:
    st.markdown("### Convert local video files to different codecs")
    
    # 코덱/해상도/품질 선택 (첫 번째 줄)
    col1, col2, col3 = st.columns([1, 1, 1])

    with col1:
        st.markdown('''
        <h3 style="font-size: 1.17em; margin-bottom: 0.5rem;">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="display: inline-block; vertical-align: middle; margin-right: 8px;">
                <circle cx="12" cy="12" r="10"></circle>
                <circle cx="12" cy="12" r="6"></circle>
                <circle cx="12" cy="12" r="2"></circle>
            </svg>
            Codec Selection
        </h3>
        ''', unsafe_allow_html=True)
        codec_options = {
            "h264": "H.264 - Best Universal Compatibility",
            "h265": "H.265 - High Compression (50% Size Reduction)",
            "vp9": "VP9 - Web Optimized (YouTube)",
            "av1": "AV1 - Next-Gen Highest Efficiency"
        }

        selected_codec = st.selectbox(
            "Select codec to convert to:",
            options=list(codec_options.keys()),
            format_func=lambda x: codec_options[x],
            index=0
        )

    with col2:
        st.markdown('''
        <h3 style="font-size: 1.17em; margin-bottom: 0.5rem;">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="display: inline-block; vertical-align: middle; margin-right: 8px;">
                <rect x="2" y="3" width="20" height="14" rx="2"></rect>
                <line x1="8" y1="21" x2="16" y2="21"></line>
                <line x1="12" y1="17" x2="12" y2="21"></line>
            </svg>
            Resolution Selection
        </h3>
        ''', unsafe_allow_html=True)
        resolution_options = {
            "original": "Keep Original",
            "4k": "4K (3840x2160)",
            "1440p": "QHD (2560x1440)",
            "1080p": "Full HD (1920x1080)",
            "720p": "HD (1280x720)",
            "480p": "SD (854x480)"
        }

        selected_resolution = st.selectbox(
            "Select resolution to convert to:",
            options=list(resolution_options.keys()),
            format_func=lambda x: resolution_options[x],
            index=0
        )

    with col3:
        st.markdown('''
        <h3 style="font-size: 1.17em; margin-bottom: 0.5rem;">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="display: inline-block; vertical-align: middle; margin-right: 8px;">
                <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"></polygon>
            </svg>
            Conversion Quality
        </h3>
        ''', unsafe_allow_html=True)
        quality_presets = {
            "fast": "Fast Conversion (Normal Quality)",
            "balanced": "Balanced (Recommended)",
            "high": "High Quality (Slow Conversion)",
            "custom": "Custom Bitrate"
        }

        selected_quality = st.selectbox(
            "Select conversion quality:",
            options=list(quality_presets.keys()),
            format_func=lambda x: quality_presets[x],
            index=1
        )

    # 프레임레이트 및 스캔 타입 선택 (두 번째 줄)
    col4, col5, col6 = st.columns([1, 1, 1])

    with col4:
        st.markdown('''
        <h3 style="font-size: 1.17em; margin-bottom: 0.5rem;">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="display: inline-block; vertical-align: middle; margin-right: 8px;">
                <rect x="2" y="2" width="20" height="20" rx="2.18" ry="2.18"></rect>
                <line x1="7" y1="2" x2="7" y2="22"></line>
                <line x1="17" y1="2" x2="17" y2="22"></line>
                <line x1="2" y1="12" x2="22" y2="12"></line>
                <line x1="2" y1="7" x2="7" y2="7"></line>
                <line x1="2" y1="17" x2="7" y2="17"></line>
                <line x1="17" y1="17" x2="22" y2="17"></line>
                <line x1="17" y1="7" x2="22" y2="7"></line>
            </svg>
            Frame Rate
        </h3>
        ''', unsafe_allow_html=True)
        fps_options = {
            "original": "Keep Original",
            "23.976": "23.976 fps (Film)",
            "24": "24 fps (Cinema)",
            "25": "25 fps (PAL)",
            "29.97": "29.97 fps (NTSC)",
            "30": "30 fps",
            "50": "50 fps (PAL Progressive)",
            "59.94": "59.94 fps (NTSC Progressive)",
            "60": "60 fps"
        }

        selected_fps = st.selectbox(
            "Select frame rate:",
            options=list(fps_options.keys()),
            format_func=lambda x: fps_options[x],
            index=0
        )

    with col5:
        st.markdown('''
        <h3 style="font-size: 1.17em; margin-bottom: 0.5rem;">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="display: inline-block; vertical-align: middle; margin-right: 8px;">
                <polygon points="23 7 16 12 23 17 23 7"></polygon>
                <rect x="1" y="5" width="15" height="14" rx="2" ry="2"></rect>
            </svg>
            Scan Type
        </h3>
        ''', unsafe_allow_html=True)
        scan_options = {
            "progressive": "Progressive",
            "interlaced": "Interlaced"
        }

        selected_scan = st.selectbox(
            "Select scan type:",
            options=list(scan_options.keys()),
            format_func=lambda x: scan_options[x],
            index=0
        )

    with col6:
        # 빈 공간 유지하되 정렬 맞춤
        st.markdown('<div style="height: 2.5rem;"></div>', unsafe_allow_html=True)
        st.markdown("")

    # Custom Bitrate 입력창 (선택했을 때만 표시)
    custom_video_br = None
    custom_audio_br = None

    if selected_quality == "custom":
        st.markdown('''
        <h3 style="font-size: 1.17em; margin-bottom: 0.5rem;">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="display: inline-block; vertical-align: middle; margin-right: 8px;">
                <line x1="4" y1="21" x2="4" y2="14"></line>
                <line x1="4" y1="10" x2="4" y2="3"></line>
                <line x1="12" y1="21" x2="12" y2="12"></line>
                <line x1="12" y1="8" x2="12" y2="3"></line>
                <line x1="20" y1="21" x2="20" y2="16"></line>
                <line x1="20" y1="12" x2="20" y2="3"></line>
                <line x1="1" y1="14" x2="7" y2="14"></line>
                <line x1="9" y1="8" x2="15" y2="8"></line>
                <line x1="17" y1="16" x2="23" y2="16"></line>
            </svg>
            Custom Bitrate Settings
        </h3>
        ''', unsafe_allow_html=True)
        col_vbr, col_abr, col_empty = st.columns([1, 1, 1])

        with col_vbr:
            custom_video_br = st.number_input(
                "Video Bitrate (Mbps):",
                min_value=1,
                max_value=100,
                value=10,
                step=1,
                help="Higher bitrate = better quality but larger file size"
            )

        with col_abr:
            custom_audio_br = st.number_input(
                "Audio Bitrate (kbps):",
                min_value=64,
                max_value=320,
                value=192,
                step=32,
                help="Recommended: 128-192 kbps for most videos"
            )

        with col_empty:
            st.markdown("")

    st.markdown("---")

    # 세션 상태 초기화
    if 'selected_folder_path' not in st.session_state:
        st.session_state['selected_folder_path'] = ""
    if 'video_files_list' not in st.session_state:
        st.session_state['video_files_list'] = []
    if 'file_selection_state' not in st.session_state:
        st.session_state['file_selection_state'] = {}
    if 'converter' not in st.session_state:
        st.session_state['converter'] = VideoConverterCore()
    if 'conversion_running' not in st.session_state:
        st.session_state['conversion_running'] = False
    if 'yt_downloader' not in st.session_state:
        st.session_state['yt_downloader'] = YouTubeDownloader()
    if 'yt_download_running' not in st.session_state:
        st.session_state['yt_download_running'] = False
    if 'yt_queue' not in st.session_state:
        st.session_state['yt_queue'] = []
    if 'yt_queue_selection' not in st.session_state:
        st.session_state['yt_queue_selection'] = {}
    if 'yt_url_input' not in st.session_state:
        st.session_state['yt_url_input'] = ""

    # File selection section
    st.markdown('''
    <h3 style="font-size: 1.17em; margin-bottom: 0.5rem;">
        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="display: inline-block; vertical-align: middle; margin-right: 8px;">
            <path d="m6 14 1.5-2.9A2 2 0 0 1 9.24 10H20a2 2 0 0 1 1.94 2.5l-1.54 6a2 2 0 0 1-1.95 1.5H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h3.9a2 2 0 0 1 1.69.9l.81 1.2a2 2 0 0 0 1.67.9H18a2 2 0 0 1 2 2v2"></path>
        </svg>
        Video File Selection
    </h3>
    ''', unsafe_allow_html=True)

    # 플랫폼별 폴더 선택 UI
    import sys

    if sys.platform == 'darwin':  # macOS
        col1, col2, col3 = st.columns([2, 1, 1])

        with col1:
            current_path = st.session_state.get('selected_folder_path', 'No files or folder selected')
            st.text_input(
                "Selected location:",
                value=current_path,
                disabled=True,
                help="Select a folder or individual files"
            )

        with col2:
            # 텍스트 입력창의 라벨("Selected location:") 높이만큼 공백 추가
            st.markdown('<div style="height: 1.5rem;"></div>', unsafe_allow_html=True)
            if st.button("Select Folder", use_container_width=True, key="btn_folder"):
                with st.spinner("📂 Opening folder dialog..."):
                    selected = open_folder_dialog()
                if selected:
                    with st.spinner("🔍 Scanning for video files..."):
                        st.rerun()

        with col3:
            st.markdown('<div style="height: 1.5rem;"></div>', unsafe_allow_html=True)
            if st.button("Select Files", use_container_width=True, key="btn_files"):
                with st.spinner("📂 Opening file dialog..."):
                    selected = open_file_dialog()
                if selected:
                    with st.spinner("📝 Loading selected files..."):
                        st.rerun()
    else:  # Windows/Linux 등
        # 수동 경로 입력
        st.info("💡 Please enter the folder path containing your video files manually:")
        
        manual_path = st.text_input(
            "Folder path:",
            value=st.session_state.get('selected_folder_path', ''),
            placeholder="e.g., /home/user/videos or C:\\Users\\user\\Videos",
            help="Enter the full path to the folder containing video files"
        )
        
        if manual_path and manual_path != st.session_state.get('selected_folder_path', ''):
            if os.path.exists(manual_path) and os.path.isdir(manual_path):
                with st.spinner("🔍 Scanning folder for video files..."):
                    st.session_state['selected_folder_path'] = manual_path
                    scan_folder_files(manual_path)
                st.success(f"✅ Folder set: {manual_path}")
                st.rerun()
            else:
                st.error("❌ Invalid folder path. Please check the path and try again.")

    # 선택된 파일들 표시 (간단한 버전)
    if st.session_state['video_files_list']:
        # 토글 카운터 초기화 (체크박스 키 리셋용)
        if 'vc_toggle_counter' not in st.session_state:
            st.session_state['vc_toggle_counter'] = 0

        # 정렬 기준 초기화
        if 'sort_by' not in st.session_state:
            st.session_state['sort_by'] = 'name'
        if 'sort_order' not in st.session_state:
            st.session_state['sort_order'] = 'asc'

        # 파일 개수 표시
        st.success(f"📹 Found {len(st.session_state['video_files_list'])} video files!")

        # 파일 정보 수집
        file_info_list = []
        for video_file in st.session_state['video_files_list']:
            file_info = {
                'path': video_file,
                'name': os.path.basename(video_file),
                'size': os.path.getsize(video_file),
                'date': os.path.getmtime(video_file)
            }
            file_info_list.append(file_info)

        # 정렬 적용
        reverse = (st.session_state['sort_order'] == 'desc')
        if st.session_state['sort_by'] == 'name':
            file_info_list.sort(key=lambda x: x['name'].lower(), reverse=reverse)
        elif st.session_state['sort_by'] == 'date':
            file_info_list.sort(key=lambda x: x['date'], reverse=reverse)
        elif st.session_state['sort_by'] == 'size':
            file_info_list.sort(key=lambda x: x['size'], reverse=reverse)

        # 파일 목록을 테이블 형식으로 표시
        selected_files = []

        st.markdown("---")

        # 체크박스, All, Size 중앙 정렬 + 세로 정렬 개선
        st.markdown("""
        <style>
        /* 체크박스를 포함한 모든 컨테이너 중앙 정렬 */
        div[data-testid="stVerticalBlock"]:has(div[data-testid="stCheckbox"]) {
            display: flex !important;
            justify-content: center !important;
            align-items: center !important;
        }

        .element-container:has(div[data-testid="stCheckbox"]) {
            display: flex !important;
            justify-content: center !important;
            align-items: center !important;
            width: 100% !important;
        }

        div[data-testid="stCheckbox"] {
            display: flex !important;
            justify-content: center !important;
            align-items: center !important;
            width: 100% !important;
        }

        div[data-testid="stCheckbox"] label {
            margin: 0 auto !important;
            display: flex !important;
            justify-content: center !important;
        }

        /* 체크박스 위젯 추가 중앙 정렬 */
        .row-widget.stCheckbox {
            display: flex !important;
            justify-content: center !important;
            width: 100% !important;
        }

        /* All 버튼 중앙 정렬 */
        button[key="toggle_all_header"] {
            text-align: center !important;
            justify-content: center !important;
        }

        /* Size 버튼 중앙 정렬 */
        button[key="sort_size"] {
            text-align: center !important;
            justify-content: center !important;
        }

        /* 첫 번째 컬럼 (체크박스/All) 중앙 정렬 */
        div[data-testid="stHorizontalBlock"] > div[data-testid="column"]:nth-child(1) {
            display: flex !important;
            justify-content: center !important;
            align-items: center !important;
        }

        /* 세 번째 컬럼 (Size) 중앙 정렬 */
        div[data-testid="stHorizontalBlock"] > div[data-testid="column"]:nth-child(3) {
            display: flex !important;
            justify-content: center !important;
            align-items: center !important;
        }
        </style>
        """, unsafe_allow_html=True)

        # 헤더 정렬 표시
        if st.session_state['sort_by'] == 'name':
            name_arrow = " ↑" if st.session_state['sort_order'] == 'asc' else " ↓"
        else:
            name_arrow = " ↕"

        if st.session_state['sort_by'] == 'size':
            size_arrow = " ↑" if st.session_state['sort_order'] == 'asc' else " ↓"
        else:
            size_arrow = " ↕"

        if st.session_state['sort_by'] == 'date':
            date_arrow = " ↑" if st.session_state['sort_order'] == 'asc' else " ↓"
        else:
            date_arrow = " ↕"

        # 테이블 헤더 (모두 버튼으로 통일)
        col_check_h, col_name_h, col_size_h, col_date_h = st.columns([0.5, 3, 1, 1.5])

        with col_check_h:
            all_selected = all(st.session_state['file_selection_state'].get(f, True) for f in st.session_state['video_files_list'])
            toggle_label = "☑ All" if all_selected else "☐ All"
            if st.button(toggle_label, key="toggle_all_header", use_container_width=True):
                new_state = not all_selected
                for video_file in st.session_state['video_files_list']:
                    st.session_state['file_selection_state'][video_file] = new_state
                st.session_state['vc_toggle_counter'] += 1  # 카운터 증가로 체크박스 키 변경
                st.rerun()

        with col_name_h:
            if st.button(f"File Name{name_arrow}", key="sort_name", use_container_width=True):
                if st.session_state['sort_by'] == 'name':
                    st.session_state['sort_order'] = 'desc' if st.session_state['sort_order'] == 'asc' else 'asc'
                else:
                    st.session_state['sort_by'] = 'name'
                    st.session_state['sort_order'] = 'asc'
                st.rerun()

        with col_size_h:
            if st.button(f"Size{size_arrow}", key="sort_size", use_container_width=True):
                if st.session_state['sort_by'] == 'size':
                    st.session_state['sort_order'] = 'desc' if st.session_state['sort_order'] == 'asc' else 'asc'
                else:
                    st.session_state['sort_by'] = 'size'
                    st.session_state['sort_order'] = 'desc'
                st.rerun()

        with col_date_h:
            if st.button(f"Modified{date_arrow}", key="sort_date", use_container_width=True):
                if st.session_state['sort_by'] == 'date':
                    st.session_state['sort_order'] = 'desc' if st.session_state['sort_order'] == 'asc' else 'asc'
                else:
                    st.session_state['sort_by'] = 'date'
                    st.session_state['sort_order'] = 'desc'
                st.rerun()

        # 파일 행들
        for i, file_info in enumerate(file_info_list):
            video_file = file_info['path']
            file_name = file_info['name']
            file_size_mb = file_info['size'] / (1024 * 1024)
            file_date = datetime.fromtimestamp(file_info['date']).strftime('%Y-%m-%d %H:%M')

            col_check, col_name, col_size, col_date = st.columns([0.5, 3, 1, 1.5])

            with col_check:
                current_state = st.session_state['file_selection_state'].get(video_file, True)
                # 토글 카운터를 포함하여 All 버튼 클릭시 체크박스 재생성
                toggle_counter = st.session_state.get('vc_toggle_counter', 0)
                file_key = f"file_check_{hash(video_file)}_{toggle_counter}"
                is_selected = st.checkbox(
                    "✓",
                    value=current_state,
                    key=file_key,
                    label_visibility="collapsed"
                )
                st.session_state['file_selection_state'][video_file] = is_selected

            with col_name:
                st.markdown(f'<p>📄 {file_name}</p>', unsafe_allow_html=True)

            with col_size:
                st.markdown(f'<p style="text-align: center;"><strong>{file_size_mb:.1f} MB</strong></p>', unsafe_allow_html=True)

            with col_date:
                st.markdown(f'<p style="text-align: center;">{file_date}</p>', unsafe_allow_html=True)

            if is_selected:
                selected_files.append(video_file)
        
        # 변환 버튼
        if selected_files:
            st.markdown("---")

            # 버튼 스타일
            st.markdown("""
            <style>
            /* Stop 버튼 스타일 */
            button[key="stop_conversion_btn"] {
                background-color: #ff4b4b !important;
                color: white !important;
            }
            button[key="stop_conversion_btn"]:hover {
                background-color: #ff0000 !important;
            }
            button[key="stop_conversion_btn"]:disabled {
                background-color: #cccccc !important;
                color: #666666 !important;
            }
            </style>
            """, unsafe_allow_html=True)

            col_start, col_stop = st.columns([3, 1])

            with col_start:
                start_conversion = st.button("Start Conversion", type="primary", use_container_width=True, disabled=st.session_state['conversion_running'])

            with col_stop:
                stop_conversion = st.button("Stop", use_container_width=True, disabled=not st.session_state['conversion_running'], key="stop_conversion_btn")
            
            if stop_conversion:
                st.session_state['converter'].stop_conversion()
                st.session_state['conversion_running'] = False
                st.warning("Conversion has been stopped.")
                st.rerun()
            
            if start_conversion and not st.session_state['conversion_running']:
                with st.spinner("⚙️ Preparing conversion..."):
                    st.session_state['conversion_running'] = True
                st.rerun()
        
        # 변환 진행
        if st.session_state.get('conversion_running', False):
            convert_videos_realtime(selected_files, selected_codec, selected_resolution, selected_quality, selected_fps, selected_scan, custom_video_br, custom_audio_br)

# 탭 2: 유튜브 다운로더
with tab2:
    st.markdown("### Download YouTube videos and convert to desired format")

    # Download Only 체크박스
    st.markdown('''
    <style>
    /* Download Only 체크박스 왼쪽 정렬 */
    .st-key-download_only_checkbox {
        text-align: left !important;
        justify-content: flex-start !important;
    }
    .st-key-download_only_checkbox label {
        justify-content: flex-start !important;
    }
    </style>
    <h3 style="font-size: 1.17em; margin-bottom: 0.5rem;">
        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="display: inline-block; vertical-align: middle; margin-right: 8px;">
            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
            <polyline points="7 10 12 15 17 10"></polyline>
            <line x1="12" y1="15" x2="12" y2="3"></line>
        </svg>
        Download Options
    </h3>
    ''', unsafe_allow_html=True)
    download_only = st.checkbox(
        "Download Only (Skip Conversion)",
        value=False,
        key="download_only_checkbox",
        help="Download the video in its original format without any conversion"
    )

    st.markdown("---")

    # 코덱/해상도/품질 선택 (유튜브용) - Download Only가 아닐 때만 표시
    if not download_only:
        st.markdown('''
        <h3 style="font-size: 1.17em; margin-bottom: 0.5rem;">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="display: inline-block; vertical-align: middle; margin-right: 8px;">
                <rect x="2" y="2" width="20" height="20" rx="2.18" ry="2.18"></rect>
                <line x1="7" y1="2" x2="7" y2="22"></line>
                <line x1="17" y1="2" x2="17" y2="22"></line>
                <line x1="2" y1="12" x2="22" y2="12"></line>
                <line x1="2" y1="7" x2="7" y2="7"></line>
                <line x1="2" y1="17" x2="7" y2="17"></line>
                <line x1="17" y1="17" x2="22" y2="17"></line>
                <line x1="17" y1="7" x2="22" y2="7"></line>
            </svg>
            Conversion Settings
        </h3>
        ''', unsafe_allow_html=True)

    # 코덱/해상도/품질 선택 (유튜브용)
    col1, col2, col3 = st.columns([1, 1, 1])

    if not download_only:
        with col1:
            st.markdown('''
            <h3 style="font-size: 1.17em; margin-bottom: 0.5rem;">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="display: inline-block; vertical-align: middle; margin-right: 8px;">
                    <circle cx="12" cy="12" r="10"></circle>
                    <circle cx="12" cy="12" r="6"></circle>
                    <circle cx="12" cy="12" r="2"></circle>
                </svg>
                Codec Selection
            </h3>
            ''', unsafe_allow_html=True)
            yt_selected_codec = st.selectbox(
                "Select codec to convert to",
                options=list(codec_options.keys()),
                format_func=lambda x: codec_options[x],
                index=0,
                key="yt_codec"
            )

        with col2:
            st.markdown('''
            <h3 style="font-size: 1.17em; margin-bottom: 0.5rem;">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="display: inline-block; vertical-align: middle; margin-right: 8px;">
                    <rect x="2" y="3" width="20" height="14" rx="2"></rect>
                    <line x1="8" y1="21" x2="16" y2="21"></line>
                    <line x1="12" y1="17" x2="12" y2="21"></line>
                </svg>
                Resolution Selection
            </h3>
            ''', unsafe_allow_html=True)
            yt_selected_resolution = st.selectbox(
                "Select resolution to convert to",
                options=list(resolution_options.keys()),
                format_func=lambda x: resolution_options[x],
                index=0,
                key="yt_resolution"
            )

        with col3:
            st.markdown('''
            <h3 style="font-size: 1.17em; margin-bottom: 0.5rem;">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="display: inline-block; vertical-align: middle; margin-right: 8px;">
                    <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"></polygon>
                </svg>
                Conversion Quality
            </h3>
            ''', unsafe_allow_html=True)
            yt_quality_presets = {
                "fast": "Fast Conversion (Normal Quality)",
                "balanced": "Balanced (Recommended)",
                "high": "High Quality (Slow Conversion)",
                "custom": "Custom Bitrate"
            }

            yt_selected_quality = st.selectbox(
                "Select conversion quality",
                options=list(yt_quality_presets.keys()),
                format_func=lambda x: yt_quality_presets[x],
                index=1,
                key="yt_quality"
            )

        # 프레임레이트 및 스캔 타입 선택 (두 번째 줄)
        col4, col5, col6 = st.columns([1, 1, 1])

        with col4:
            st.markdown('''
            <h3 style="font-size: 1.17em; margin-bottom: 0.5rem;">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="display: inline-block; vertical-align: middle; margin-right: 8px;">
                    <rect x="2" y="2" width="20" height="20" rx="2.18" ry="2.18"></rect>
                    <line x1="7" y1="2" x2="7" y2="22"></line>
                    <line x1="17" y1="2" x2="17" y2="22"></line>
                    <line x1="2" y1="12" x2="22" y2="12"></line>
                    <line x1="2" y1="7" x2="7" y2="7"></line>
                    <line x1="2" y1="17" x2="7" y2="17"></line>
                    <line x1="17" y1="17" x2="22" y2="17"></line>
                    <line x1="17" y1="7" x2="22" y2="7"></line>
                </svg>
                Frame Rate
            </h3>
            ''', unsafe_allow_html=True)
            yt_selected_fps = st.selectbox(
                "Select frame rate:",
                options=list(fps_options.keys()),
                format_func=lambda x: fps_options[x],
                index=0,
                key="yt_fps"
            )

        with col5:
            st.markdown('''
            <h3 style="font-size: 1.17em; margin-bottom: 0.5rem;">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="display: inline-block; vertical-align: middle; margin-right: 8px;">
                    <polygon points="23 7 16 12 23 17 23 7"></polygon>
                    <rect x="1" y="5" width="15" height="14" rx="2" ry="2"></rect>
                </svg>
                Scan Type
            </h3>
            ''', unsafe_allow_html=True)
            yt_selected_scan = st.selectbox(
                "Select scan type:",
                options=list(scan_options.keys()),
                format_func=lambda x: scan_options[x],
                index=0,
                key="yt_scan"
            )

        with col6:
            # 빈 공간 유지하되 정렬 맞춤
            st.markdown('<div style="height: 2.5rem;"></div>', unsafe_allow_html=True)
            st.markdown("")

        # Custom Bitrate 입력창 (선택했을 때만 표시)
        yt_custom_video_br = None
        yt_custom_audio_br = None

        if yt_selected_quality == "custom":
            st.markdown('''
            <h3 style="font-size: 1.17em; margin-bottom: 0.5rem;">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="display: inline-block; vertical-align: middle; margin-right: 8px;">
                    <line x1="4" y1="21" x2="4" y2="14"></line>
                    <line x1="4" y1="10" x2="4" y2="3"></line>
                    <line x1="12" y1="21" x2="12" y2="12"></line>
                    <line x1="12" y1="8" x2="12" y2="3"></line>
                    <line x1="20" y1="21" x2="20" y2="16"></line>
                    <line x1="20" y1="12" x2="20" y2="3"></line>
                    <line x1="1" y1="14" x2="7" y2="14"></line>
                    <line x1="9" y1="8" x2="15" y2="8"></line>
                    <line x1="17" y1="16" x2="23" y2="16"></line>
                </svg>
                Custom Bitrate Settings
            </h3>
            ''', unsafe_allow_html=True)
            col_vbr, col_abr, col_empty = st.columns([1, 1, 1])

            with col_vbr:
                yt_custom_video_br = st.number_input(
                    "Video Bitrate (Mbps):",
                    min_value=1,
                    max_value=100,
                    value=10,
                    step=1,
                    help="Higher bitrate = better quality but larger file size",
                    key="yt_custom_vbr"
                )

            with col_abr:
                yt_custom_audio_br = st.number_input(
                    "Audio Bitrate (kbps):",
                    min_value=64,
                    max_value=320,
                    value=192,
                    step=32,
                    help="Recommended: 128-192 kbps for most videos",
                    key="yt_custom_abr"
                )

            with col_empty:
                st.markdown("")
    else:
        # Download Only 선택 시 기본값 설정
        yt_selected_codec = "h264"
        yt_selected_resolution = "original"
        yt_selected_quality = "balanced"
        yt_selected_fps = "original"
        yt_selected_scan = "progressive"
        yt_custom_video_br = None
        yt_custom_audio_br = None

    st.markdown("---")

    # 저장 위치 선택 (기본값: 사용자의 Downloads 폴더)
    if 'yt_save_folder_path' not in st.session_state:
        downloads_folder = os.path.join(os.path.expanduser("~"), "Downloads")
        st.session_state['yt_save_folder_path'] = downloads_folder

    # 저장 위치 UI 표시
    st.markdown('''
    <h3 style="font-size: 1.17em; margin-bottom: 0.5rem;">
        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="display: inline-block; vertical-align: middle; margin-right: 8px;">
            <path d="m6 14 1.5-2.9A2 2 0 0 1 9.24 10H20a2 2 0 0 1 1.94 2.5l-1.54 6a2 2 0 0 1-1.95 1.5H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h3.9a2 2 0 0 1 1.69.9l.81 1.2a2 2 0 0 0 1.67.9H18a2 2 0 0 1 2 2v2"></path>
        </svg>
        Download Location
    </h3>
    ''', unsafe_allow_html=True)
    col1, col2 = st.columns([3, 1])

    with col1:
        st.text_input(
            "Download file save location:",
            value=st.session_state['yt_save_folder_path'],
            disabled=True,
            label_visibility="collapsed"
        )

    with col2:
        if st.button("Select Folder", key="yt_folder_select", use_container_width=True):
            selected = open_folder_dialog()
            if selected:
                st.session_state['yt_save_folder_path'] = selected
                st.rerun()

    st.markdown("---")

    # 유튜브 URL 입력
    st.markdown('''
    <h3>
        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="display: inline-block; vertical-align: middle; margin-right: 8px;">
            <path d="M2.5 17a24.12 24.12 0 0 1 0-10 2 2 0 0 1 1.4-1.4 49.56 49.56 0 0 1 16.2 0A2 2 0 0 1 21.5 7a24.12 24.12 0 0 1 0 10 2 2 0 0 1-1.4 1.4 49.55 49.55 0 0 1-16.2 0A2 2 0 0 1 2.5 17"></path>
            <path d="m10 15 5-3-5-3z"></path>
        </svg>
        YouTube URL Input
    </h3>
    ''', unsafe_allow_html=True)

    col_url, col_download, col_queue = st.columns([3, 1, 1])

    with col_url:
        youtube_url = st.text_input(
            "Enter YouTube video URL:",
            value=st.session_state.get('yt_url_input', ''),
            placeholder="https://www.youtube.com/watch?v=...",
            help="Supports YouTube video and playlist URLs",
            key="yt_url_input_field",
            label_visibility="collapsed"
        )

    # URL이 변경되면 세션 상태 업데이트
    if youtube_url != st.session_state.get('yt_url_input', ''):
        st.session_state['yt_url_input'] = youtube_url

    # 단일 다운로드 버튼
    with col_download:
        st.markdown("<div style='margin-top: 0px;'>", unsafe_allow_html=True)
        download_now_btn = st.button(
            "Download Now",
            use_container_width=True,
            disabled=not youtube_url or st.session_state.get('yt_download_running', False),
            key="yt_download_now",
            type="primary"
        )
        st.markdown("</div>", unsafe_allow_html=True)

    # 큐에 추가 버튼
    with col_queue:
        st.markdown("<div style='margin-top: 0px;'>", unsafe_allow_html=True)
        add_to_queue_btn = st.button(
            "Add to Queue",
            use_container_width=True,
            disabled=not youtube_url or st.session_state.get('yt_download_running', False),
            key="yt_add_to_queue"
        )
        st.markdown("</div>", unsafe_allow_html=True)
    
    # yt-dlp 설치 확인 (skip - causes false warnings)
    # if youtube_url and not st.session_state['yt_downloader'].check_yt_dlp():
    #     st.error("❌ yt-dlp is not installed. Run `pip install yt-dlp` or `brew install yt-dlp` in terminal.")

    # "Download Now" 버튼 클릭 시 즉시 다운로드
    if download_now_btn and youtube_url:
        st.session_state['yt_download_running'] = True
        download_and_convert_youtube(
            youtube_url,
            yt_selected_codec,
            yt_selected_resolution,
            yt_selected_quality,
            yt_selected_fps,
            yt_selected_scan,
            yt_custom_video_br,
            yt_custom_audio_br,
            download_only
        )
        st.session_state['yt_download_running'] = False
        # URL 입력창 초기화 (rerun 제거 - 완료 메시지 유지)
        st.session_state['yt_url_input'] = ""

    # "Add to Queue" 버튼 클릭 시 큐에 추가 (빠른 제목만 fetch)
    if add_to_queue_btn and youtube_url:
        # 이미 Queue에 있는지 확인
        already_in_queue = youtube_url in [item['url'] for item in st.session_state['yt_queue']]

        if not already_in_queue:
            with st.spinner("📺 Fetching video title..."):
                video_info = st.session_state['yt_downloader'].get_video_title_fast(youtube_url)

            if video_info:
                # Queue에 추가
                queue_item = {
                    'url': youtube_url,
                    'info': video_info,
                    'settings': {
                        'codec': yt_selected_codec,
                        'resolution': yt_selected_resolution,
                        'quality': yt_selected_quality,
                        'fps': yt_selected_fps,
                        'scan': yt_selected_scan,
                        'custom_video_br': yt_custom_video_br,
                        'custom_audio_br': yt_custom_audio_br,
                        'download_only': download_only
                    }
                }

                st.session_state['yt_queue'].append(queue_item)
                st.session_state['yt_queue_selection'][youtube_url] = True

                # 성공 메시지
                st.success(f"✅ Added to queue: {video_info['title']}")

                # URL 입력창 초기화
                st.session_state['yt_url_input'] = ""
                st.rerun()
            else:
                st.error("❌ Cannot fetch video title. Please check the URL or try again.")
        else:
            st.warning("⚠️ This video is already in the queue!")
    
    # YouTube Download Queue 표시 (큐에 항목이 있을 때만)
    if st.session_state['yt_queue']:
        st.markdown("---")
        st.markdown('''
        <h3 style="font-size: 1.17em; margin-bottom: 0.5rem;">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="display: inline-block; vertical-align: middle; margin-right: 8px;">
                <line x1="8" y1="6" x2="21" y2="6"></line>
                <line x1="8" y1="12" x2="21" y2="12"></line>
                <line x1="8" y1="18" x2="21" y2="18"></line>
                <line x1="3" y1="6" x2="3.01" y2="6"></line>
                <line x1="3" y1="12" x2="3.01" y2="12"></line>
                <line x1="3" y1="18" x2="3.01" y2="18"></line>
            </svg>
            Download Queue
        </h3>
        ''', unsafe_allow_html=True)
        st.success(f"📹 {len(st.session_state['yt_queue'])} video(s) in queue")

        # Queue 컨트롤 버튼
        col_select, col_clear, col_empty = st.columns([1, 1, 2])

        with col_select:
            # 토글 카운터 초기화 (체크박스 키 리셋용)
            if 'yt_toggle_counter' not in st.session_state:
                st.session_state['yt_toggle_counter'] = 0

            # 현재 모두 선택되어 있는지 확인
            all_selected = all(st.session_state['yt_queue_selection'].get(item['url'], True) for item in st.session_state['yt_queue'])
            select_btn_label = "☐ Deselect All" if all_selected else "☑️ Select All"

            if st.button(select_btn_label, use_container_width=True, key="yt_select_all"):
                new_state = not all_selected
                for item in st.session_state['yt_queue']:
                    st.session_state['yt_queue_selection'][item['url']] = new_state
                st.session_state['yt_toggle_counter'] += 1  # 카운터 증가로 체크박스 키 변경
                st.rerun()

        with col_clear:
            if st.button("Clear Queue", use_container_width=True, key="yt_clear_queue"):
                st.session_state['yt_queue'] = []
                st.session_state['yt_queue_selection'] = {}
                st.rerun()

        st.markdown("---")

        # Queue 항목 표시
        items_to_remove = []

        for idx, item in enumerate(st.session_state['yt_queue']):
            url = item['url']
            info = item['info']
            settings = item['settings']

            # 카드 스타일 컨테이너
            with st.container():
                col_check, col_info, col_remove = st.columns([0.5, 5, 0.8])

                with col_check:
                    # 카운터를 키에 포함시켜 토글 버튼 클릭 시 체크박스 재생성
                    toggle_counter = st.session_state.get('yt_toggle_counter', 0)
                    is_selected = st.checkbox(
                        "✓",
                        value=st.session_state['yt_queue_selection'].get(url, True),
                        key=f"yt_queue_check_{idx}_{toggle_counter}",
                        label_visibility="collapsed"
                    )
                    st.session_state['yt_queue_selection'][url] = is_selected

                with col_info:
                    # 비디오 제목
                    st.markdown(f"**📺 {info['title']}**")

                    # 비디오 정보 (간단한 정보만 표시)
                    info_parts = []

                    if info.get('uploader') and info['uploader'] != 'Unknown':
                        info_parts.append(f"👤 {info['uploader']}")

                    if info.get('duration', 0) > 0:
                        duration_min = info['duration'] // 60
                        duration_sec = info['duration'] % 60
                        info_parts.append(f"⏱️ {duration_min:02d}:{duration_sec:02d}")

                    if info.get('view_count', 0) > 0:
                        view_count = info['view_count']
                        if view_count > 1000000:
                            view_str = f"{view_count/1000000:.1f}M"
                        elif view_count > 1000:
                            view_str = f"{view_count/1000:.1f}K"
                        else:
                            view_str = str(view_count)
                        info_parts.append(f"👀 {view_str}")

                    if info_parts:
                        st.markdown(" | ".join(info_parts))
                    else:
                        st.markdown("*Details will be fetched during download*")

                    # 변환 설정 표시
                    if settings['download_only']:
                        st.markdown("**Download Only** (No Conversion)")
                    else:
                        codec_name = codec_options[settings['codec']].split(' - ')[0]
                        res_name = resolution_options[settings['resolution']]
                        fps_name = fps_options[settings['fps']]

                        if settings['quality'] == 'custom':
                            quality_str = f"Custom ({settings['custom_video_br']}Mbps / {settings['custom_audio_br']}kbps)"
                        else:
                            quality_str = quality_presets[settings['quality']].split(' (')[0]

                        st.markdown(f"🎬 **Convert to:** {codec_name}, {res_name}, {quality_str}, {fps_name}")

                with col_remove:
                    st.markdown("<br>", unsafe_allow_html=True)
                    if st.button("✕", key=f"yt_remove_{idx}", help="Remove from queue"):
                        items_to_remove.append(idx)

                st.markdown("---")

        # 삭제할 항목 처리
        if items_to_remove:
            for idx in sorted(items_to_remove, reverse=True):
                removed_url = st.session_state['yt_queue'][idx]['url']
                st.session_state['yt_queue'].pop(idx)
                if removed_url in st.session_state['yt_queue_selection']:
                    del st.session_state['yt_queue_selection'][removed_url]
            st.rerun()

        # 선택된 항목 개수
        selected_count = sum(1 for item in st.session_state['yt_queue']
                           if st.session_state['yt_queue_selection'].get(item['url'], True))

        # 배치 다운로드 버튼
        if selected_count > 0:
            col1, col2 = st.columns([3, 1])
            with col1:
                start_batch = st.button(
                    f"Start Batch Download/Convert ({selected_count} selected)",
                    type="primary",
                    use_container_width=True,
                    disabled=st.session_state.get('yt_download_running', False)
                )
            with col2:
                # 빨강색 스톱 버튼 스타일
                st.markdown("""
                <style>
                button[key="yt_stop_batch"] {
                    background-color: #ff4b4b !important;
                    color: white !important;
                }
                button[key="yt_stop_batch"]:hover {
                    background-color: #ff0000 !important;
                }
                button[key="yt_stop_batch"]:disabled {
                    background-color: #cccccc !important;
                    color: #666666 !important;
                }
                </style>
                """, unsafe_allow_html=True)
                stop_batch = st.button(
                    "Stop",
                    disabled=not st.session_state.get('yt_download_running', False),
                    key="yt_stop_batch",
                    use_container_width=True
                )

            if stop_batch:
                st.session_state['yt_downloader'].stop_download()
                st.session_state['converter'].stop_conversion()
                st.session_state['yt_download_running'] = False
                st.warning("Batch operation has been stopped.")
                st.rerun()

            if start_batch and not st.session_state.get('yt_download_running', False):
                with st.spinner("⚙️ Preparing batch download/conversion..."):
                    st.session_state['yt_download_running'] = True
                st.rerun()

    # 배치 다운로드 + 변환 진행
    if st.session_state.get('yt_download_running', False) and st.session_state['yt_queue']:
        # 선택된 항목만 필터링
        selected_items = [item for item in st.session_state['yt_queue']
                         if st.session_state['yt_queue_selection'].get(item['url'], True)]

        if selected_items:
            batch_download_and_convert(selected_items)
# 푸터
st.markdown("---")
st.markdown("""
<div style="text-align: center; color: #666; padding: 2rem;">
    <p>🎥 Video Tool v5.0 - Made by Channy</p>
    <p>Video conversion tool with batch YouTube download support.</p>
</div>
""", unsafe_allow_html=True)